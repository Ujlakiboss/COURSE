﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleApp1;


public class Hallgato
{
    public string Nev { get; set; }
    public string Nem { get; set; }
    public int Backend { get; set; }
    public int Frontend { get; set; }
    public int Adatbazis { get; set; }
    public int Java { get; set; }
    public int Python { get; set; }
    public int Eloleg { get; set; }

    public Hallgato(string nev, string nem, int backend, int frontend, int adatbazis, int java, int python, int eloleg)
    {
        Nev = nev;
        Nem = nem;
        Backend = backend;
        Frontend = frontend;
        Adatbazis = adatbazis;
        Java = java;
        Python = python;
        Eloleg = eloleg;
    }

    public double Atlag()
    {
        return (Backend + Frontend + Adatbazis + Java + Python) / 5.0;
    }

    public int OsszesPont()
    {
        return Backend + Frontend + Adatbazis + Java + Python;
    }

    public List<string> SzuksegesJavito()
    {
        List<string> javitando = new List<string>();
        if (Backend < 51) javitando.Add("Backend");
        if (Frontend < 51) javitando.Add("Frontend");
        if (Adatbazis < 51) javitando.Add("Adatbázis");
        if (Java < 51) javitando.Add("Java");
        if (Python < 51) javitando.Add("Python");
        return javitando;
    }
}

class Program
{
    static List<Hallgato> Beolvasas(string filename)
    {
        List<Hallgato> hallgatok = new List<Hallgato>();
        try
        {
            using (StreamReader reader = new StreamReader("course.txt", System.Text.Encoding.UTF8))
            {
                string header = reader.ReadLine(); 
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(';');
                    if (values.Length != 8)
                    {
                        Console.WriteLine($"Hiba a sor feldolgozása során: {line}. Nem megfelelő számú oszlop.");
                        continue; 

                    try
                    {
                        string nev = values[0];
                        string nem = values[1];
                        int backend = int.Parse(values[2]);
                        int frontend = int.Parse(values[3]);
                        int adatbazis = int.Parse(values[4]);
                        int java = int.Parse(values[5]);
                        int python = int.Parse(values[6]);
                        int eloleg = int.Parse(values[7]);

                        Hallgato hallgato = new Hallgato(nev, nem, backend, frontend, adatbazis, java, python, eloleg);
                        hallgatok.Add(hallgato);
                    }
                    catch (FormatException e)
                    {
                        Console.WriteLine($"Hiba a sor feldolgozása során: {line}. Formátum hiba: {e.Message}");
                    }
                }
            }
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine($"A fájl nem található.");
        }
        catch (Exception e)
        {
            Console.WriteLine($"Hiba a fájl beolvasása közben: {e.Message}");
        }
        return hallgatok;
    }

    static void Main(string[] args)
    {
        string filename = "course.txt"; 
        List<Hallgato> hallgatok = Beolvasas(filename);

        if (hallgatok.Count == 0)
        {
            Console.WriteLine("Nincsenek adatok a fájlban, vagy hiba történt a beolvasáskor.");
            return;
        }


        
        Console.WriteLine($"1. Hallgatók száma: {hallgatok.Count}");

        
        double backendAtlag = hallgatok.Average(h => h.Backend);
        Console.WriteLine($"2. Backend átlag: {backendAtlag:F2}"); 

        
        Hallgato osztalyelso = hallgatok.OrderByDescending(h => h.OsszesPont()).FirstOrDefault();
        if (osztalyelso != null)
        {
            Console.WriteLine($"3. Osztályelső: {osztalyelso.Nev} ({osztalyelso.OsszesPont()} pont)");
        }
        else
        {
            Console.WriteLine("3. Nincsenek hallgatók a fájlban.");
        }

       
        double ferfiakAranya = (double)hallgatok.Count(h => h.Nem == "F") / hallgatok.Count * 100;
        Console.WriteLine($"4. Férfiak aránya: {ferfiakAranya:F2}%");

        
        Hallgato legjobbNoi = hallgatok.Where(h => h.Nem == "N").OrderByDescending(h => h.Frontend + h.Backend).FirstOrDefault();
        if (legjobbNoi != null)
        {
            Console.WriteLine($"5. Legjobb női webfejlesztő: {legjobbNoi.Nev} ({legjobbNoi.Frontend + legjobbNoi.Backend} pont)");
        }
        else
        {
            Console.WriteLine("5. Nincsenek női hallgatók a fájlban.");
        }


        
        int tanfolyamAra = 2600;
        List<Hallgato> teljesenFizettek = hallgatok.Where(h => h.Eloleg >= tanfolyamAra).ToList();
        if (teljesenFizettek.Count > 0)
        {
            Console.WriteLine("6. Teljesen fizetett hallgatók:");
            foreach (Hallgato hallgato in teljesenFizettek)
            {
                Console.WriteLine($"   - {hallgato.Nev}");
            }
        }
        else
        {
            Console.WriteLine("6. Nincs teljesen fizetett hallgató.");
        }

        
        Console.Write("7. Kérem a hallgató nevét: ");
        string bekertNev = Console.ReadLine();
        Hallgato talaltHallgato = hallgatok.FirstOrDefault(h => h.Nev == bekertNev);

        if (talaltHallgato != null)
        {
            List<string> javitandoTantargyak = talaltHallgato.SzuksegesJavito();
            if (javitandoTantargyak.Count > 0)
            {
                Console.WriteLine($"{bekertNev} javítót kell tennie a következő tantárgyakból:");
                foreach (string tantargy in javitandoTantargyak)
                {
                    Console.WriteLine($"   - {tantargy}");
                }
            }
            else
            {
                Console.WriteLine($"{bekertNev} nem szorul javítóvizsgára.");
            }
        }
        else
        {
            Console.WriteLine("Nem található ilyen hallgató.");
        }

        
        int szazFelettiEsJavitoNelkuli = hallgatok.Count(h => (h.Backend == 100 || h.Frontend == 100 || h.Adatbazis == 100 || h.Java == 100 || h.Python == 100) && h.SzuksegesJavito().Count == 0);
        Console.WriteLine($"8. 100%-ot teljesítő és javító nélküli hallgatók száma: {szazFelettiEsJavitoNelkuli}");


        
        var javitoModulonkent = new Dictionary<string, int>();
        foreach (Hallgato hallgato in hallgatok)
        {
            foreach (string modul in hallgato.SzuksegesJavito())
            {
                if (javitoModulonkent.ContainsKey(modul))
                {
                    javitoModulonkent[modul]++;
                }
                else
                {
                    javitoModulonkent[modul] = 1;
                }
            }
        }

        Console.WriteLine("9. Modulonként javítóvizsgát igénylők száma:");
        foreach (var item in javitoModulonkent)
        {
            Console.WriteLine($"   - {item.Key}: {item.Value}");
        }

        
        List<Hallgato> rendezettHallgatok = hallgatok.OrderBy(h => h.Nev.Split(' ').Last()).ToList(); 
        string kimenetiFajl = "rendezett_hallgatok.txt";
        try
        {
            using (StreamWriter writer = new StreamWriter(kimenetiFajl, false, System.Text.Encoding.UTF8))
            {
                foreach (Hallgato hallgato in rendezettHallgatok)
                {
                    writer.WriteLine($"{hallgato.Nev} - Átlag: {hallgato.Atlag():F2}");
                }
            }
            Console.WriteLine($"10. Hallgatók rendezve és kiírva a '{kimenetiFajl}' fájlba.");
        }
        catch (Exception e)
        {
            Console.WriteLine($"Hiba a fájlba íráskor: {e.Message}");
        }


        Console.ReadKey();
    }
}